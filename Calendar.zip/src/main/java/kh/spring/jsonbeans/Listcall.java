package kh.spring.jsonbeans;

public class Listcall {
	public String val1;
	public String val2;
}
